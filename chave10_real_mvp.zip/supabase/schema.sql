create extension if not exists pgcrypto;

create table public.offices (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 document text,
 phone text,
 whatsapp text,
 email text,
 address text,
 created_at timestamptz not null default now()
);

create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 office_id uuid references public.offices(id) on delete cascade,
 name text,
 role text not null default 'owner',
 created_at timestamptz not null default now()
);

create table public.customers (
 id uuid primary key default gen_random_uuid(),
 office_id uuid not null references public.offices(id) on delete cascade,
 name text not null,
 document text,
 phone text,
 whatsapp text,
 email text,
 address text,
 notes text,
 created_at timestamptz not null default now()
);

create table public.vehicles (
 id uuid primary key default gen_random_uuid(),
 office_id uuid not null references public.offices(id) on delete cascade,
 customer_id uuid not null references public.customers(id) on delete cascade,
 plate text not null,
 brand text,
 model text,
 year integer,
 color text,
 mileage integer default 0,
 chassis text,
 fuel text,
 notes text,
 created_at timestamptz not null default now()
);

create table public.quotes (
 id uuid primary key default gen_random_uuid(),
 office_id uuid not null references public.offices(id) on delete cascade,
 customer_id uuid not null references public.customers(id),
 vehicle_id uuid not null references public.vehicles(id),
 number bigint generated always as identity,
 mileage integer,
 problem text,
 discount numeric(10,2) not null default 0,
 total numeric(10,2) not null default 0,
 status text not null default 'draft' check(status in ('draft','sent','approved','rejected')),
 valid_until date,
 created_at timestamptz not null default now()
);

create table public.quote_items (
 id uuid primary key default gen_random_uuid(),
 office_id uuid not null references public.offices(id) on delete cascade,
 quote_id uuid not null references public.quotes(id) on delete cascade,
 type text not null check(type in ('service','part')),
 description text not null,
 quantity numeric(10,2) not null,
 unit_price numeric(10,2) not null,
 total numeric(10,2) generated always as (quantity*unit_price) stored
);

create table public.work_orders (
 id uuid primary key default gen_random_uuid(),
 office_id uuid not null references public.offices(id) on delete cascade,
 customer_id uuid not null references public.customers(id),
 vehicle_id uuid not null references public.vehicles(id),
 quote_id uuid references public.quotes(id),
 number bigint generated always as identity,
 mileage integer,
 reported_problem text,
 diagnosis text,
 notes text,
 total numeric(10,2) not null default 0,
 status text not null default 'open' check(status in ('open','in_progress','waiting_part','finished','delivered')),
 created_at timestamptz not null default now(),
 finished_at timestamptz
);

create table public.work_order_items (
 id uuid primary key default gen_random_uuid(),
 office_id uuid not null references public.offices(id) on delete cascade,
 work_order_id uuid not null references public.work_orders(id) on delete cascade,
 type text not null check(type in ('service','part')),
 description text not null,
 quantity numeric(10,2) not null,
 unit_price numeric(10,2) not null,
 total numeric(10,2) generated always as (quantity*unit_price) stored
);

create or replace function public.current_office_id()
returns uuid language sql stable security definer set search_path=public
as $$ select office_id from public.profiles where id=auth.uid() $$;

alter table public.profiles enable row level security;
alter table public.offices enable row level security;
alter table public.customers enable row level security;
alter table public.vehicles enable row level security;
alter table public.quotes enable row level security;
alter table public.quote_items enable row level security;
alter table public.work_orders enable row level security;
alter table public.work_order_items enable row level security;

create policy "profile own" on public.profiles for select using (id=auth.uid());
create policy "office members select" on public.offices for select using (id=public.current_office_id());

create policy "customers office" on public.customers for all using (office_id=public.current_office_id()) with check (office_id=public.current_office_id());
create policy "vehicles office" on public.vehicles for all using (office_id=public.current_office_id()) with check (office_id=public.current_office_id());
create policy "quotes office" on public.quotes for all using (office_id=public.current_office_id()) with check (office_id=public.current_office_id());
create policy "quote items office" on public.quote_items for all using (office_id=public.current_office_id()) with check (office_id=public.current_office_id());
create policy "os office" on public.work_orders for all using (office_id=public.current_office_id()) with check (office_id=public.current_office_id());
create policy "os items office" on public.work_order_items for all using (office_id=public.current_office_id()) with check (office_id=public.current_office_id());

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
declare new_office uuid;
begin
 insert into public.offices(name,email) values (coalesce(new.raw_user_meta_data->>'office_name','Nova Oficina'),new.email) returning id into new_office;
 insert into public.profiles(id,office_id,name) values (new.id,new_office,coalesce(new.raw_user_meta_data->>'name','Administrador'));
 return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
